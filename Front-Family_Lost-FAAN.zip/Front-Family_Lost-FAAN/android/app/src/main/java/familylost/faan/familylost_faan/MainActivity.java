package familylost.faan.familylost_faan;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
